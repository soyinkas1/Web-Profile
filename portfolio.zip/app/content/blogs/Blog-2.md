title: To the Future Me (WIP)
date: 1999-09-09
published: No

<span style="color:red"> Busy creating the content &#128075; ...</span>

![Gif](https://media.tenor.com/jNgKSlUpmkEAAAAC/typing-laptop.gif)
