---
title: Xero Practice Manager ETL and rethinking reporting with Billing 
date: 2024-04-25
published: True
shortDesc:
img: "static/assets/img/portfolio/Reports Dashboards.png"
---
Working on this....

Question on why ETL?

Use case?
