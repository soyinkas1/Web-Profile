---
date: 23-07-2023
name: Abass Akinsanya
comment: "Soyinka's ability to impact and influence a team is exceptional. His ability to lead from the front coupled with his immense flexibility in managing complex situations and his team members is a rare quality found in most managers"
relationship: Worked together on same team
title: Executive Director
linkedinProfile: https://www.linkedin.com/in/abass-soji-akinsanya-bsc-msc-pmp-87664648
---
