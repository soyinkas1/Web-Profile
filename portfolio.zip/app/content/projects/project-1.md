title: Create a dashboard to meet business requirements - Department for Education (DfE) Bootcamp 
shortDesc: A data visualization dashboard was created using Tableau for a globally present company, aiming to standardize project monitoring. This will help management track project performance, measuring both current status and future projections.
date: 2022-12-12
tech: Tableau Desktop, Tableau Prep, miro.com (mock-up)
codeLink: https://github.com/soyinkas1/PP0007_DfE-AMS-OpenClassrooms-Data-Analysis-Bootcamp_Excel_Tableau-PowerBI_Python_SQL/tree/master/Project%202
webHost: https://public.tableau.com/views/Sowoolu_Soyinka_1_dashboard_122022/RoleSelector?:language=en-GB&:display_count=n&:origin=viz_share_link
readMore:  
filterClass: filter-data-anal
img: "static/assets/img/portfolio/Reports Dashboards.png"
tag: Data Analysis